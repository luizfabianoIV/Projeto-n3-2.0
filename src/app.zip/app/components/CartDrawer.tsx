"use client";
import Image from "next/image";
import { useCartStore } from "@/store";
import { formatPrice } from "@/lib/utils";

export default function CartDrawer() {
  const {
    cart,
    isOpen,
    toggleCart,
    increaseQty,
    decreaseQty,
    removeById,
  } = useCartStore();

  const total = cart.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  );

  return (
    <div className={`fixed top-0 right-0 h-full w-80 bg-gray-800 shadow-xl 
      transform transition-all duration-300 p-5 
      ${isOpen ? "translate-x-0" : "translate-x-full"}`}>

      <button className="text-2xl mb-4" onClick={toggleCart}>×</button>

      <h2 className="text-xl font-bold mb-4">Seu carrinho</h2>

      <div className="flex flex-col gap-4">
        {cart.map((item) => (
          <div key={item.id} className="flex gap-3 items-center border-b pb-3">
            <Image
              src={item.image}
              width={50}
              height={50}
              alt={item.name}
              className="rounded"
            />

            <div className="flex flex-col flex-1">
              <span>{item.name}</span>
              <span className="font-semibold">{formatPrice(item.price)}</span>

              <div className="flex items-center gap-2 mt-1">
                <button
                  className="px-2 bg-gray-200 rounded"
                  onClick={() => decreaseQty(item.id)}
                >
                  -
                </button>

                <span className="w-6 text-center">{item.quantity}</span>

                <button
                  className="px-2 bg-gray-200 rounded"
                  onClick={() => increaseQty(item.id)}
                >
                  +
                </button>

                <button
                  className="text-red-600 ml-auto"
                  onClick={() => removeById(item.id)}
                >
                  Remover
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-4 border-t">
        <p className="text-lg font-semibold">
          Total: {formatPrice(total)}
        </p>

        <button className="w-full mt-4 bg-blue-600 text-white py-3 rounded-lg">
          Finalizar compra
        </button>
      </div>
    </div>
  );
}
