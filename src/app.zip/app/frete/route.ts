import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { cep } = await req.json();

    if (!cep) {
      return NextResponse.json({ error: "CEP obrigatório" }, { status: 400 });
    }

    // Valores mínimos aceitos pelo Melhor Envio
    const pacote = {
      height: 2,       // cm
      width: 11,       // cm
      length: 16,      // cm
      weight: 0.3      // kg
    };

    const body = {
      from: { postal_code: "78558210" }, // CEP DA SUA LOJA (mudo depois)
      to: { postal_code: cep },
      package: pacote
    };

    const response = await fetch(
      "https://www.melhorenvio.com.br/api/v2/me/shipment/calculate",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "Authorization": `Bearer ${process.env.MELHOR_ENVIO_TOKEN}`,
          "User-Agent": "NextJS App"
        },
        body: JSON.stringify(body)
      }
    );

    const data = await response.json();

    if (!Array.isArray(data) || data.length === 0) {
      return NextResponse.json({ error: "Nenhum frete encontrado" }, { status: 400 });
    }

    // pega o frete mais barato
    const menorFrete = Math.min(...data.map((f: any) => Number(f.price)));

    return NextResponse.json({ frete: menorFrete });
  } catch (err) {
    console.error("ERRO FRETE:", err);
    return NextResponse.json({ error: "Erro ao calcular frete" }, { status: 500 });
  }
}